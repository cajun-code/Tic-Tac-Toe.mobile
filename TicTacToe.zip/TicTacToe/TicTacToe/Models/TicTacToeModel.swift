//
//  TicTacToeModel.swift
//  TicTacToe
//
//  Created by Brandon Riehle on 2/25/19.
//  Copyright © 2019 Brandon Riehle. All rights reserved.
//

import Foundation

struct TicTacToeModel {

    //real board user is playing with
    var realBoard: [Piece] = Array(repeating: .E, count: 9)
    //the computer board
    let minMaxBoard: [Piece]
    let turn: Piece
    let lastMove: Int
    
    var humanMarks:Piece = .X
    var computerMarks:Piece = .O

    init(board: [Piece] = Array(repeating: .E, count: 9), turn: Piece = .X, lastMove: Int = -1) {
        self.minMaxBoard = board
        self.turn = turn
        self.lastMove = lastMove
    }
    
    mutating func reset() {
        realBoard = Array(repeating: .E, count: 9)
    }

    mutating func setHumanAndComp(human:Piece,computer:Piece) {
        humanMarks = human
        computerMarks = computer
    }

    func didWin(_ position:[Piece])->Bool {
        //top
        if position[0] == position[1] && position[0] == position[2] && position[0] != .E {
            return true
        }
        //left
        if position[0] == position[3] && position[0] == position[6] && position[0] != .E {
            return true
        }
        //middle vertical
        if position[1] == position[4] && position[1] == position[7] && position[1] != .E {
            return true
        }
        //middle horizontal
        if position[3] == position[4] && position[3] == position[5] && position[3] != .E {
            return true
        }
        //bottom
        if position[6] == position[7] && position[8] == position[6] && position[6] != .E {
            return true
        }
        //right
        if position[2] == position[5] && position[2] == position[8] && position[2] != .E {
            return true
        }
        //diagonal
        if position[0] == position[4] && position[0] == position[8] && position[0] != .E {
            return true
        }
        //diagonal2
        if position[6] == position[4] && position[6] == position[2] && position[6] != .E {
            return true
        }
        return false
    }
    
    func isADraw(pieces:[Piece]) -> Bool {
        return pieces.filter({$0 == .E}).count == 0 && !didWin(pieces)
    }
    
    //open positions
    private var availableMoves:[Int] {
        return minMaxBoard.indices.filter({minMaxBoard[$0] == .E})
    }
    
    mutating func markTicTacToeBoard(index:Int) -> String? {
        if realBoard[index] == .E {

            realBoard[index] = humanMarks
            
            if didWin(realBoard) {
                return "Human Wins!"
            }
            else if isADraw(pieces: realBoard){
                return "Draw!"
            }
            
            //new board to analyze moves
            let board = TicTacToeModel(board: realBoard, turn: computerMarks, lastMove: index)
            let answer = findBestMove(board)
            print("findBestMove:\(answer)")
            
            realBoard[answer] = computerMarks
            
            if didWin(realBoard) {
                return "Computer Wins!"
            }
            else if isADraw(pieces: realBoard){
                return "Draw!"
            }
        }
        return nil
    }

    func move(_ location: Int) -> TicTacToeModel {
        var tempPosition = minMaxBoard
        tempPosition[location] = turn
        return TicTacToeModel(board: tempPosition, turn: turn.opposite, lastMove: location)
    }
    
    func findBestMove(_ board: TicTacToeModel) -> Int {
        var bestEval = Int.min
        var bestMove = -1
        for move in board.availableMoves {
            let result = minimax(board.move(move), maximizing: true, originalPlayer: board.turn)
            print(result)
            if result > bestEval {
                bestEval = result
                bestMove = move
            }
        }
        return bestMove
    }
    
    private func minimax(_ board: TicTacToeModel, maximizing: Bool, originalPlayer: Piece) -> Int {
        // Base case — evaluate the position if it is a win or a draw
        if board.didWin(board.minMaxBoard) && originalPlayer == board.turn.opposite { return 1 } // win
        else if board.didWin(board.minMaxBoard) && originalPlayer == board.turn { return -1 } // loss
        else if board.isADraw(pieces: board.minMaxBoard) { return 0 } // draw
        
        // Recursive case — maximize your gains or minimize the opponent's gains
        if maximizing {
            var bestEval = Int.min
            for move in board.availableMoves { // find the move with the highest evaluation
                let result = minimax(board.move(move), maximizing: false, originalPlayer: originalPlayer)
                bestEval = max(result, bestEval)
            }
            return bestEval
        }
        else { // minimizing
            var worstEval = Int.max
            for move in board.availableMoves {
                let result = minimax(board.move(move), maximizing: true, originalPlayer: originalPlayer)
                worstEval = min(result, worstEval)
            }
            return worstEval
        }
    }
}

enum Piece:String {
    case X = "X"
    case O = "O"
    case E = ""
    
    var opposite: Piece {
        switch self {
        case .X:
            return .O
        case .O:
            return .X
        case .E:
            return .E
        }
    }
}
