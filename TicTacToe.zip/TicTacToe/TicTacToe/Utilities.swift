//
//  Utilities.swift
//  TicTacToe
//
//  Created by Brandon Riehle on 2/26/19.
//  Copyright © 2019 Brandon Riehle. All rights reserved.
//

import UIKit


class Utilities {
    
    //MARK: Fonts
    class func getAttrStr(_ text: String, with size: CGFloat, color:UIColor) -> NSAttributedString {
        let font = UIFontMetrics(forTextStyle: .headline).scaledFont(for: UIFont.preferredFont(forTextStyle: .headline).withSize(size))
        
        return NSAttributedString(string: text, attributes: [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: color])
    }
    
    class func attrStr(_ text:String) -> NSAttributedString {
        
        if Piece.O.rawValue == text {
            return getAttrStr(text, with: 70.0, color: UIColor.red)
        }
        else {
            return getAttrStr(text, with: 70.0, color: UIColor.blue)
        }
    }
}


