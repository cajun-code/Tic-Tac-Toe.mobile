//
//  ViewController.swift
//  TicTacToe
//
//  Created by Brandon Riehle on 2/25/19.
//  Copyright © 2019 Brandon Riehle. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //Model
    var ticTacToeModel = TicTacToeModel()
    
    //OUTLETS
    @IBOutlet private var ticTacButtons: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //Present User with Alert to choose either
        let choiceAlertController = UIAlertController(title: "Xs or Os?", message: "Choose Xs or Os to start the game", preferredStyle: .actionSheet)
        choiceAlertController.addAction(UIAlertAction(title: "Xs", style: .default, handler: { [weak self](alert) in
            self?.ticTacToeModel.setHumanAndComp(human: Piece.X, computer: Piece.O)
        }))
        choiceAlertController.addAction(UIAlertAction(title: "Os", style: .default, handler: { [weak self](alert) in
            self?.ticTacToeModel.setHumanAndComp(human: Piece.O, computer: Piece.X)
        }))
        
        present(choiceAlertController, animated: true)
    }
    
    private func updateViewFromModel() {
        for index in ticTacButtons.indices {
            let modelData = ticTacToeModel.realBoard[index]
            let button = ticTacButtons[index]
            
            switch (modelData) {
            case .X:
                button.setAttributedTitle(Utilities.attrStr(modelData.rawValue), for: .normal)
            case .O:
                button.setAttributedTitle(Utilities.attrStr(modelData.rawValue), for: .normal)
            default:
                button.setAttributedTitle(NSAttributedString(), for: .normal)
            }
        }
    }
    
    @IBAction func boardButtonAction(_ sender: UIButton) {
        if let buttonIndex = ticTacButtons.index(of: sender) {
            if let winner = ticTacToeModel.markTicTacToeBoard(index: buttonIndex) {
                 presentWinnerAlert(winner)
            }
            updateViewFromModel()
        }
    }
    
    func presentWinnerAlert(_ winningText:String?) {
        
        if winningText != nil {
            let winnerAlert = UIAlertController(title: winningText!, message: nil, preferredStyle: .alert)
            winnerAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self] (alert) in
                self?.ticTacToeModel.reset()
                self?.updateViewFromModel()
            }))
            present(winnerAlert, animated: true)
        }
    }
}
