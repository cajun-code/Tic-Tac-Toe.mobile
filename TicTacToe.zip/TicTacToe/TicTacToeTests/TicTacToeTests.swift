//
//  TicTacToeTests.swift
//  TicTacToeTests
//
//  Created by Brandon Riehle on 2/25/19.
//  Copyright © 2019 Brandon Riehle. All rights reserved.
//

import XCTest
@testable import TicTacToe

class TicTacToeTests: XCTestCase {

    var ticTacToeModel:TicTacToeModel!
    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        ticTacToeModel = TicTacToeModel()
    }
    
    func testTicTacToeInit() {
        XCTAssert(ticTacToeModel.realBoard.filter({$0 == .E}).count == 9)
        XCTAssert(ticTacToeModel.minMaxBoard.filter({$0 == .E}).count == 9)
    }
    
    func testDraw() {
        ticTacToeModel.realBoard[0] = .O
        ticTacToeModel.realBoard[1] = .X
        ticTacToeModel.realBoard[2] = .X
        ticTacToeModel.realBoard[3] = .X
        ticTacToeModel.realBoard[4] = .O
        ticTacToeModel.realBoard[5] = .O
        ticTacToeModel.realBoard[6] = .X
        ticTacToeModel.realBoard[7] = .O
        ticTacToeModel.realBoard[8] = .X
        XCTAssert(ticTacToeModel.isADraw(pieces: ticTacToeModel.realBoard))
    }
    
    func testMiddleOfGameNoWinnerYet() {
        ticTacToeModel.realBoard[0] = .O
        ticTacToeModel.realBoard[1] = .X
        ticTacToeModel.realBoard[2] = .O
        ticTacToeModel.realBoard[3] = .X
        ticTacToeModel.realBoard[4] = .X
        XCTAssertFalse(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowOnTop() {
        ticTacToeModel.realBoard[0] = .O
        ticTacToeModel.realBoard[1] = .O
        ticTacToeModel.realBoard[2] = .O
        
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowOnLeft() {
        ticTacToeModel.realBoard[0] = .X
        ticTacToeModel.realBoard[3] = .X
        ticTacToeModel.realBoard[6] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowOnRight() {
        ticTacToeModel.realBoard[2] = .X
        ticTacToeModel.realBoard[5] = .X
        ticTacToeModel.realBoard[8] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowOnBottom() {
        ticTacToeModel.realBoard[6] = .X
        ticTacToeModel.realBoard[7] = .X
        ticTacToeModel.realBoard[8] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowVerticalMiddle() {
        
        ticTacToeModel.realBoard[1] = .X
        ticTacToeModel.realBoard[4] = .X
        ticTacToeModel.realBoard[7] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowHorizontalMiddle() {
        
        ticTacToeModel.realBoard[3] = .X
        ticTacToeModel.realBoard[4] = .X
        ticTacToeModel.realBoard[5] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowDiagonal1() {
        
        ticTacToeModel.realBoard[0] = .X
        ticTacToeModel.realBoard[4] = .X
        ticTacToeModel.realBoard[8] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func test3inARowDiagonal2() {
        
        ticTacToeModel.realBoard[2] = .X
        ticTacToeModel.realBoard[4] = .X
        ticTacToeModel.realBoard[6] = .X
        XCTAssert(ticTacToeModel.didWin(ticTacToeModel.realBoard))
    }
    
    func testClearBoard() {
        ticTacToeModel.reset()
        XCTAssert(ticTacToeModel.minMaxBoard.filter({$0 == .E}).count == 9)
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        ticTacToeModel = nil
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
}
